package com.springboot.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.application.model.User;

/**
 * The interface User repository.
 *
 * @author Basha
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {}
