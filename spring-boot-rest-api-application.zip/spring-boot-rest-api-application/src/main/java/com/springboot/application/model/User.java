package com.springboot.application.model;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;

import java.util.Date;

/**
 * The type User.
 *
 * @author Basha
 */
@Entity
@Table(name = "orders")
@EntityListeners(AuditingEntityListener.class)
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long hotel_id;
	
	@Column(name = "hotel_name", nullable = false)
	private String hotelName;

	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "mobileNumber", nullable = false)
	private String mobileNumber;

	@Column(name = "email_address", nullable = false)
	private String email;
	
	@Column(name = "room_id", nullable = false) 	
	private String roomId;
	
	@Column(name = "room_name", nullable = false) 
	 private String roomName;
	 
	 @Column(name = "no_Of_guest", nullable = false)
	 private String noofGuest;
	 
	 @Column(name = "totalamout", nullable = false) 
	 private double totalAmount;
	 
	 @CreationTimestamp
	 @Temporal(TemporalType.DATE)
	 @JsonFormat(pattern="yyyy-MM-dd")
	 @Column(name = "checkin_date", nullable = false) 
	 private Date checkinDate;
	 
	 @CreationTimestamp
	 @Temporal(TemporalType.DATE)
	 @JsonFormat(pattern="yyyy-MM-dd")
	 @Column(name = "checkout_date", nullable = false)
	 private Date checkoutDate;
	 
	 public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getNoofGuest() {
		return noofGuest;
	}

	public void setNoofGuest(String string) {
		this.noofGuest = string;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Date getCheckinDate() {
		return checkinDate;
	}

	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}

	public Date getCheckoutDate() {
		return checkoutDate;
	}

	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}

	public long getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(long hotel_id) {
		this.hotel_id = hotel_id;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	@Override
	public String toString() {
		return "User [hotel_id=" + hotel_id + ", hotelName=" + hotelName + ", name=" + name + ", mobileNumber="
				+ mobileNumber + ", email=" + email + ", roomId=" + roomId + ", roomName=" + roomName + ", noofGuest="
				+ noofGuest + ", totalAmount=" + totalAmount + ", checkinDate=" + checkinDate + ", checkoutDate="
				+ checkoutDate + "]";
	}
	
	}
